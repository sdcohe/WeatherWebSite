<!-- start #footer -->
<div id="footer">
	<p>
		Copyright &copy; 2007-<?php print date('Y')?>, Clopper&#39;s Mill East Weather Website |<span class="doNotPrint"> Powered by Java, PHP, and AJAX</span><br />

		<span class="emphasize">This weather station and Web site are privately owned, 
			and are not the officially recognized system of record for the local weather conditions.<br />
			Never base important decisions on this or any
			weather information obtained from the Internet.</span> <br />
		
		<br
			class="doNotPrint" /> Some images and maps courtesy of <a
			href="http://www.wunderground.com/" title="Weather Underground">Weather
			Underground</a> and <a href="http://www.weather.gov//"
			title="The National Weather Service">The National Weather Service</a> <br />
			
		<span class="doNotPrint">This Web site is based on a design by <a
			href="http://www.freecsstemplates.org/">Free CSS Templates</a>.</span>
			
		<br class="doNotPrint" /> <br class="doNotPrint" /> <a href="#header">Top</a>
		| <a class="doNotPrint" 
			href="http://www.google.com/recaptcha/mailhide/d?k=01PACIEH7h8qqBY2Sp6Y8saQ==&amp;c=vZ869VoTk2zh8h6EVU2a7ib19t6L6xPUluXzExp5pv8="
			onclick="window.open('http://www.google.com/recaptcha/mailhide/d?k\07501PACIEH7h8qqBY2Sp6Y8saQ\75\75\46c\75vZ869VoTk2zh8h6EVU2a7ib19t6L6xPUluXzExp5pv8\075', '',
			'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=500,height=300'); return false;"
			title="Reveal this e-mail address">Email us</a>


		<script type="text/javascript">
		<!--
		if (navigator.appName == 'Microsoft Internet Explorer' &&
		parseInt(navigator.appVersion) >= 4)
		{
			document.write('| <a href=\"#\" onclick=\"javascript:window.external.AddFavorite(location.href,document.title)\">');
			document.write('Bookmark Page</a>');
		}else
		{var msg = '| <a href="" title="Bookmark Page" onClick="alert(' + "'Hit CTRL-D to bookmark this page'"+ ');">Bookmark Page</a>';
		if(navigator.appName == "Netscape") msg += " (CTRL-D)";
		document.write(msg);
		}
		// -->
		</script>
		| <a href="http://validator.w3.org/check?uri=referer"
			title="Click to validate our HTML">Valid HTML</a> | <a
			href="http://jigsaw.w3.org/css-validator/check/referer"
			title="Click to validate our CSS">Valid CSS</a>
	</p>
</div>
<!-- end #footer -->