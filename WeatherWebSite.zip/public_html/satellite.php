<!DOCTYPE html>
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Exploitable 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20090327

-->
<html>


<?php
require_once "config/config.php";

$cfg = config::getInstance();
date_default_timezone_set($cfg->getTimeZone());
?>

<head>
<meta name="keywords" content="" />
<meta name="keywords" content="germantown,Clopper&#39;s,Mill,Clopper&#39;s Mill,weather" />
<meta name="description" content="Personal weather station located in Germantown, MD 20874." />

<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<script type="text/javascript" src="config/config.js.php"></script>
<script type="text/javascript" src="js/jQuery.js"></script>
<script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="js/jQueryTimer.js"></script>
<script type="text/javascript" src="js/weatherconversions.js"></script>
<!--  <script type="text/javascript" src="/min//?g=weatherjs"></script>  -->
<script type='text/javascript' src='js/date.js'></script>
<script type='text/javascript' src='js/knockout.js'></script>
<script type='text/javascript' src='js/knockoutmapping.js'></script>
<script type='text/javascript' src='js/weathermodel.js'></script>

<title>Clopper&#39;s Mill East Weather</title>

<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
<link id="favicon" rel="shortcut icon" href="/favicon.ico" type="image/x-icon">

</head>

<body>
<script type="text/javascript">

$(document).ready(function(){
	
	initWeatherDataModel();
	
	// get WX data every 15 secs
	$(document).everyTime(dataRefreshRate, retrieveWeatherData);

	//get WX stats every minute
	$(document).everyTime(statsRefreshRate, retrieveWeatherStats);

	//get update web cam image every 30 secs
	$("#webcamThumbnail").everyTime(webcamRefreshRate, updateWebcam);

	// update favicon every 10 minutes based on weather forecast
	$(document).everyTime(faviconRefreshRate, updateFavicon);
});

</script>

	<div id="wrapper">
		

<?php
include_once "pageheader.php";
include_once "pagenavigation.php";
?>

		<div id="page">
			 
<?php
include_once "pageadvisory.php";
?>

			<!--  		<div id="page-bgtop"> -->
			<div id="page-bgbtm">
				<div id="content">
					<h2>All images on this page courtesy of Marshall Space Flight Center Earth Science Office and the National Hurricane Center</h2> 
					<div class="post">
						<div class="post-bgtop">
							<div class="post-bgbtm">
								<h2 class="title">GOES East US Visible</h2>
								<p class="meta"></p>
								<div class="entry">
									<iframe class="sat-image" src="https://weather.msfc.nasa.gov/cgi-bin/get-abi?satellite=GOESEastconusband02&lat=<?php print $cfg->getLatitude()?>&lon=<?php print $cfg->getLongitude()?>&zoom=4&width=650&height=450&quality=100" ></iframe> 
								</div>
							</div>
						</div>
					</div>
					<div class="post">
						<div class="post-bgtop">
							<div class="post-bgbtm">
								<h2 class="title">GOES NW Atlantic Visible</h2>
								<p class="meta"></p>
								<div class="entry">
									<iframe class="sat-image" src="https://weather.msfc.nasa.gov/cgi-bin/get-abi?satellite=GOESEastfullDiskband14&lat=30&lon=-51&zoom=4&width=650&height=450&quality=100" ></iframe> 
								</div>
							</div>
						</div>
					</div>
					<div class="post">
						<div class="post-bgtop">
							<div class="post-bgbtm">
								<h2 class="title">GOES Carribean Visible</h2>
								<p class="meta"></p>
								<div class="entry">
									<iframe class="sat-image" src="https://weather.msfc.nasa.gov/cgi-bin/get-abi?satellite=GOESEastfullDiskband14&lat=20&lon=-78.7&zoom=4&width=650&height=450&quality=100" ></iframe> 
								</div>
							</div>
						</div>
					</div>
					<div class="post">
						<div class="post-bgtop">
							<div class="post-bgbtm">
								<h2 class="title">5 Day Tropical Weather Outlook</h2>
								<p class="meta"></p>
								<div class="entry">
									<img class="sat-image" src="https://www.nhc.noaa.gov/xgtwo/two_atl_5d0.png" ></img> 
									<img class="sat-image" src="https://www.nhc.noaa.gov/xgtwo/two_pac_5d0.png" ></img> 
								</div>
							</div>
						</div>
					</div>
					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				
<?php
include_once "pagesidebar.php";
?>
					<div style="clear: both;">&nbsp;</div>
 				</div>
			<!-- 			</div>  -->
		</div>
		<!-- end #page -->
		
<?php
include_once "pagefooter.php";
?>	
</div>
</body>
</html>
